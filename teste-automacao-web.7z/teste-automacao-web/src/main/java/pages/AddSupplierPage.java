package pages;

import static support.DriverFactory.getDriver;

import org.junit.Assert;
import org.openqa.selenium.By;

public class AddSupplierPage {
	public void setName() {
		getDriver().findElement(By.xpath("//input[@name=\"fname\"]")).sendKeys("Anderson");		
	}
	
	public void setLastName() {
		getDriver().findElement(By.xpath("//input[@name=\"lname\"]")).sendKeys("Rodrigues");	
	}
	
	public void setEmail() {
		getDriver().findElement(By.xpath("//input[@name=\"email\"]")).sendKeys("ande.ads@hotmail.com");
	}
	
	public void setPassword() {
		getDriver().findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("anderson10");
	}
	
	public void setCountry() {
		getDriver().findElement(By.xpath("//input[@id=\"s2id_autogen2\"]")).sendKeys("Brazil");
		getDriver().findElement(By.xpath("//option[@value=\"BR\"]")).click();
	}
	
	public void summit() {
		getDriver().findElement(By.xpath("//button[contains(.,\"Submit\")]")).click();
	}
	
	public void requiredEmail() {
		String texto = getDriver().findElement(By.xpath("//div[@class=\"alert alert-danger\"]/p")).getText();
		Assert.assertEquals("The Email field is required.", texto);
		
	}
}
